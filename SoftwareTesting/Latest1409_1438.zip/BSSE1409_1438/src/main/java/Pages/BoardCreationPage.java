package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import java.util.List;
import java.util.stream.Collectors;

public class BoardCreationPage {
    private final WebDriver driver;

    // Web elements on the board creation page
    private final By boardLink = By.cssSelector("#\\35-board1 > .inner");
    private final By columnHeaders = By.cssSelector("h4");
    private final By addNewCardLink = By.linkText("Add a new card...");
    private final By cardContent = By.cssSelector(".card-content > span");
    private final By cardNameInput = By.id("card_name");
    private final By submitButton = By.cssSelector("button");
    private final By cancelLink = By.linkText("cancel");
    private final By boardNameInput = By.id("board_name");
    private final By boardHeader = By.cssSelector("h3");
    private final By deleteCardButton = By.cssSelector(".delete"); // Retained for reference, used in deleteCard
    private final By boardsNav = By.cssSelector("#boards_nav span");
    private final By viewAllBoardsLink = By.linkText("View all boards");
    private final By headerText = By.cssSelector("h3 > span");

    public BoardCreationPage(WebDriver driver) {
        this.driver = driver;
    }

    // Methods to interact with the board details
    public void clickBoardLink() {
        WebElement boardLinkElement = driver.findElement(boardLink);
        boardLinkElement.click();
    }

    public boolean areColumnHeadersPresent() {
        List<WebElement> elements = driver.findElements(columnHeaders);
        return !elements.isEmpty();
    }

    public void clickAddNewCardLink() {
        WebElement addNewCardLinkElement = driver.findElement(addNewCardLink);
        addNewCardLinkElement.click();
    }

    public String getCardContentText() {
        WebElement cardContentElement = driver.findElement(cardContent);
        return cardContentElement.getText();
    }

    public List<String> getAllCardContentTexts() {
        List<WebElement> cardElements = driver.findElements(cardContent);
        return cardElements.stream().map(WebElement::getText).collect(Collectors.toList());
    }

    // Methods to interact with the card creation form
    public void enterCardName(String cardName) {
        WebElement cardNameElement = driver.findElement(cardNameInput);
        cardNameElement.clear();
        cardNameElement.sendKeys(cardName);
    }

    public void clickSubmitButton() {
        WebElement submitButtonElement = driver.findElement(submitButton);
        submitButtonElement.click();
    }

    public boolean isCancelLinkPresent() {
        List<WebElement> elements = driver.findElements(cancelLink);
        return !elements.isEmpty();
    }

    public void clickCancelLink() {
        WebElement cancelLinkElement = driver.findElement(cancelLink);
        cancelLinkElement.click();
    }

    // Methods retained from previous BoardCreationPage
    public void enterBoardName(String boardName) {
        WebElement boardNameElement = driver.findElement(boardNameInput);
        boardNameElement.clear();
        boardNameElement.sendKeys(boardName);
    }

    public String getBoardHeaderText() {
        WebElement boardHeaderElement = driver.findElement(boardHeader);
        return boardHeaderElement.getText();
    }

    public String getBoardNameErrorMessage() {
        WebElement boardNameElement = driver.findElement(boardNameInput);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        return (String) js.executeScript("return arguments[0].validationMessage;", boardNameElement);
    }

    public String getCardNameErrorMessage() {
        WebElement cardNameElement = driver.findElement(cardNameInput);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        return (String) js.executeScript("return arguments[0].validationMessage;", cardNameElement);
    }

    // Method to delete a card by its content
    public void deleteCard(String cardName) {
        List<WebElement> cardElements = driver.findElements(cardContent);
        for (WebElement cardElement : cardElements) {
            if (cardElement.getText().equals(cardName)) {
                cardElement.click(); // Step 1: Open modal

                WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

                try {
                    // Step 2: Wait for modal to appear
                    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".md-modal")));

                    // Step 3: Wait for delete button to be clickable
                    WebElement deleteButton = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".md-modal .delete")));
                    deleteButton.click();

                    // Step 4: Wait until modal disappears (optional, included for robustness)
                    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".md-modal")));

                    // Step 5: Wait until the card is removed from the list
                    wait.until(ExpectedConditions.invisibilityOf(cardElement));
                    return;

                } catch (Exception e) {
                    throw new RuntimeException("Failed to delete card: " + cardName + ". Error: " + e.getMessage());
                }
            }
        }
        throw new RuntimeException("Card with name " + cardName + " not found");
    }

    // New methods from BoardsPage
    public boolean isBoardsNavPresent() {
        List<WebElement> elements = driver.findElements(boardsNav);
        return !elements.isEmpty();
    }

    public void clickBoardsNav() {
        WebElement boardsNavElement = driver.findElement(boardsNav);
        boardsNavElement.click();
    }

    public boolean isViewAllBoardsLinkPresent() {
        List<WebElement> elements = driver.findElements(viewAllBoardsLink);
        return !elements.isEmpty();
    }

    public void clickViewAllBoardsLink() {
        WebElement viewAllBoardsLinkElement = driver.findElement(viewAllBoardsLink);
        viewAllBoardsLinkElement.click();
    }

    public String getHeaderText() {
        WebElement headerElement = driver.findElement(headerText);
        return headerElement.getText();
    }
}