package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class BoardCreationPage {
    private final WebDriver driver;

    // Web elements on the board creation page
    private final By boardNameInput = By.id("board_name");
    private final By submitButton = By.cssSelector("button");
    private final By boardHeader = By.cssSelector("h3");

    public BoardCreationPage(WebDriver driver) {
        this.driver = driver;
    }

    // Methods to interact with the board creation page
    public void enterBoardName(String boardName) {
        WebElement boardNameElement = driver.findElement(boardNameInput);
        boardNameElement.clear();
        boardNameElement.sendKeys(boardName);
    }

    public void clickSubmitButton() {
        WebElement submitButtonElement = driver.findElement(submitButton);
        submitButtonElement.click();
    }

    public String getBoardHeaderText() {
        WebElement boardHeaderElement = driver.findElement(boardHeader);
        return boardHeaderElement.getText();
    }
}