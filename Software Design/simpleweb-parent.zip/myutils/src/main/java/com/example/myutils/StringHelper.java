package com.example.myutils;

public class StringHelper {
    public static String shout(String msg) {
        return msg.toUpperCase() + "!!!";
    }
}
